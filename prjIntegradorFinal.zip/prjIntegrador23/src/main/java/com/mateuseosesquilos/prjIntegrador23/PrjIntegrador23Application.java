package com.mateuseosesquilos.prjIntegrador23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjIntegrador23Application {

	public static void main(String[] args) {
		SpringApplication.run(PrjIntegrador23Application.class, args);
	}

}
